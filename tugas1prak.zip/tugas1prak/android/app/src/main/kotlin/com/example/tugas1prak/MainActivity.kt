package com.example.tugas1prak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
